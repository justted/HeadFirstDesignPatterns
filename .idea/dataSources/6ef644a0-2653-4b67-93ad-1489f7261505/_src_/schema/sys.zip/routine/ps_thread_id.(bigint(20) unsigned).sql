CREATE FUNCTION ps_thread_id(in_connection_id BIGINT)
  RETURNS BIGINT
  BEGIN RETURN (SELECT THREAD_ID FROM `performance_schema`.`threads` WHERE PROCESSLIST_ID = IFNULL(in_connection_id, CONNECTION_ID()) ); END;
